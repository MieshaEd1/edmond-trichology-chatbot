from fastapi import FastAPI, Request
from pydantic import BaseModel
import openai
import os

app = FastAPI()

openai.api_key = os.getenv("OPENAI_API_KEY")

class UserMessage(BaseModel):
    message: str

@app.post("/chat")
async def chat(user_message: UserMessage):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are the Edmond Trichology Assistant, a certified trichologist helping clients with hair loss. Recommend consultations and products from Edmond Trichology. If they’re ready, direct them to book here: https://miesha-k.as.me/?appointmentType=81715848"},
                {"role": "user", "content": user_message.message}
            ]
        )
        reply = response["choices"][0]["message"]["content"]
        return {"reply": reply}
    except Exception as e:
        return {"error": str(e)}
# Edmond Trichology Assistant Chatbot

This is a FastAPI-based chatbot assistant for Edmond Trichology, designed to be deployed on Render.